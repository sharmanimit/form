import {
  Button,
  Grid,
  makeStyles,
  TextField,
  Select,
  MenuItem,
} from "@material-ui/core";
import { React, useState } from "react";
import SearchIcon from "@material-ui/icons/Search";
import { ColumnDirective, ColumnsDirective, Filter, GridComponent, Inject, Page, Resize, Sort } from "@syncfusion/ej2-react-grids";

const useStyles = makeStyles({
  root: {
    padding: "2rem",
    minHeight: "100vh",
    backgroundColor: "#ddd",
  },
  input: {
    backgroundColor: "#fff",
  },
  submitButton: {
    float: "right",
  },
});

export const Gridsystem = () => {
  const classes = useStyles();

  return (
    <Grid className={classes.root}>
      <div
        style={{
          marginBottom: "1rem",
          float: "left",
          border: "1px",
          textDecoration: "underline",
        }}
      >
        <b>ADVANCE SEARCH PAGE</b>
      </div>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <div style={{ marginBottom: "0.5rem", float: "left" }}>FROM:</div>
          <TextField
            type="date"
            className={classes.input}
            variant="outlined"
            fullWidth
            size="small"
          />
        </Grid>
        <Grid item xs={6}>
          <div style={{ marginBottom: "0.5rem", float: "left" }}>TO:</div>
          <TextField
            type="date"
            className={classes.input}
            variant="outlined"
            fullWidth
            size="small"
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            className={classes.input}
            variant="outlined"
            fullWidth
            size="small"
            label="DOC SUB:"
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            native="true"
            className={classes.input}
            variant="outlined"
            fullWidth
            size="small"
            label="TYPE:"
          >
            <MenuItem value="">Choose one option</MenuItem>
            <MenuItem value="3">NOTING</MenuItem>
            <MenuItem value="6">ENCLOSURE</MenuItem>
            <MenuItem value="9">SERVICE LETTER</MenuItem>
            <MenuItem value="12">SERVICE NOTE</MenuItem>
            <MenuItem value="16">MINUTE OF METTING</MenuItem>
            <MenuItem value="18">DEMO OFFICIAL</MenuItem>
          </TextField>
        </Grid>
        <Grid item xs={4}>
          <TextField
            className={classes.input}
            variant="outlined"
            fullWidth
            size="small"
            label="FILE:"
          />
        </Grid>
        <Grid item xs={4}>
          <TextField
            className={classes.input}
            variant="outlined"
            fullWidth
            size="small"
            label="FILE SUBJECT:"
          />
        </Grid>
        <Grid item xs={4}>
          <TextField
            className={classes.input}
            variant="outlined"
            fullWidth
            size="small"
            label="OLD FILE REFERENCE:"
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            className={classes.input}
            variant="outlined"
            fullWidth
            size="small"
            label="CONTENT:"
          />
        </Grid>
        <Grid item xs={12}>
          <Button
            startIcon={<SearchIcon />}
            className={classes.submitButton}
            variant="contained"
            color="primary"
            style={{marginBottom:"0.5rem"}}
          >
            Search
          </Button>
        </Grid>
      </Grid>
      <Grid>
        <GridComponent
          dataSource={[]}
          height="400"
          allowResizing={true}
          allowSorting={true}
          allowPaging={true}
          pageSettings={{ pageCount: 5, pageSizes: true }}
          allowFiltering={true}
          filterSettings={{ type: "Menu" }}
        >
          <ColumnsDirective>
            <ColumnDirective
              field="type"
              headerText={"TYPE"}
              width="90"
              textAlign="left"
            ></ColumnDirective>
            <ColumnDirective
              field="file subject"
              width="200"
              headerText={"FILE SUBJECT"}
            ></ColumnDirective>
            <ColumnDirective
              field="Doc subject"
              headerText={"DOC SUBJECT"}
              width="150"
              textAlign="center"
            />
             <ColumnDirective
              field="File"
              headerText={"FILE"}
              width="130"
              format="yMd"
              textAlign="center"
            ></ColumnDirective>
            <ColumnDirective
              field="modified date"
              headerText={"MODIFIED DATE"}
              // template={statusTemplate}
              width="120"
              textAlign="Right"
            />
            <ColumnDirective
              field="CREATED BY"
              headerText={"CREATED BY"}
              width="130"
              format="yMd"
              textAlign="Right"
            ></ColumnDirective>
            
          </ColumnsDirective>
          <Inject services={[Resize, Sort, Filter, Page]} />
        </GridComponent>
      </Grid>
    </Grid>
  );
};
